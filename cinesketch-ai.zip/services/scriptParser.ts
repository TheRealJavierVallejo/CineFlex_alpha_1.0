
/*
 * 📜 SERVICE: SCRIPT PARSER
 * 
 * This file reads screenplay files (specifically .fountain format).
 * It turns text like "INT. HOUSE - DAY" into structured Scene data
 * that the app can understand and turn into shots.
 */

import { Scene, ScriptElement } from '../types';

export interface ParsedScript {
  scenes: Scene[];
  elements: ScriptElement[];
  metadata: {
    title?: string;
    author?: string;
  };
}

// Main entry point
export async function parseScript(file: File): Promise<ParsedScript> {
  const text = await file.text();
  const filename = file.name.toLowerCase();

  if (filename.endsWith('.fountain') || filename.endsWith('.txt')) {
    return parseFountain(text);
  } else {
    throw new Error(`Unsupported format: ${filename}. Only .fountain and .txt are currently supported.`);
  }
}

// Helper: Determine if a line is a scene heading
const isSceneHeading = (line: string): boolean => {
  const s = line.trim().toUpperCase();
  return /^(INT\.|EXT\.|INT\/EXT\.|I\/E\.|INT\/EXT)(\s+|$)/.test(s) || s.startsWith('.');
};

// Helper: Determine if a line is a character name
const isCharacter = (line: string): boolean => {
  const s = line.trim();
  // Must be all caps, not empty, not a scene heading, and usually centered in PDFs but here just check caps
  // In Fountain, character names are uppercase and precede dialogue
  return s.length > 0 && s === s.toUpperCase() && !isSceneHeading(s) && !s.endsWith('TO:');
};

// Helper: Determine if a line is a transition
const isTransition = (line: string): boolean => {
  const s = line.trim().toUpperCase();
  return s.endsWith('TO:') || s.startsWith('>');
};

// Helper: Extract metadata from scene heading
const extractLocation = (heading: string): string => {
  // Remove INT./EXT. prefix and time suffix
  let clean = heading.trim().replace(/^\.?\s*(INT\.|EXT\.|INT\/EXT\.|I\/E\.|INT\/EXT)\s*/i, '');
  clean = clean.split(/\s+-\s+/)[0]; // Remove " - DAY"
  return clean;
};

const extractTimeOfDay = (heading: string): string => {
  const parts = heading.trim().split(/\s+-\s+/);
  return parts.length > 1 ? parts[parts.length - 1] : '';
};

// 🖋️ FOUNTAIN PARSER IMPLEMENTATION
function parseFountain(text: string): ParsedScript {
  const lines = text.split(/\r?\n/);
  const elements: ScriptElement[] = [];
  const scenes: Scene[] = [];
  
  let currentScene: Scene | null = null;
  let elementSequence = 1;
  let sceneSequence = 1;
  let lastLineWasBlank = true;

  // Metadata
  const metadata: any = {};
  
  // Parsing Loop
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // Skip initial blank lines
    if (!line) {
      lastLineWasBlank = true;
      continue;
    }

    // Metadata Key-Value pairs at start of file
    if (elementSequence === 1 && line.includes(':') && !isSceneHeading(line) && !isCharacter(line)) {
       const [key, val] = line.split(':').map(s => s.trim());
       if (key && val) {
          metadata[key.toLowerCase()] = val;
          continue; 
       }
    }

    // 1. SCENE HEADING
    if (isSceneHeading(line)) {
       const newScene: Scene = {
          id: crypto.randomUUID(),
          sequence: sceneSequence++,
          heading: line.startsWith('.') ? line.substring(1).toUpperCase() : line.toUpperCase(),
          actionNotes: '',
          scriptElements: []
       };
       scenes.push(newScene);
       currentScene = newScene;

       const el: ScriptElement = {
         id: crypto.randomUUID(),
         type: 'scene_heading',
         content: newScene.heading,
         sceneId: newScene.id,
         sequence: elementSequence++
       };
       elements.push(el);
       lastLineWasBlank = false;
       continue;
    }

    // 2. TRANSITIONS
    if (isTransition(line)) {
      const el: ScriptElement = {
        id: crypto.randomUUID(),
        type: 'transition',
        content: line.startsWith('>') ? line.substring(1).trim() : line,
        sceneId: currentScene?.id,
        sequence: elementSequence++
      };
      elements.push(el);
      lastLineWasBlank = false;
      continue;
    }

    // 3. CHARACTER & DIALOGUE
    // If line is uppercase and previous line was blank, it's likely a character
    if (lastLineWasBlank && isCharacter(line)) {
       const charEl: ScriptElement = {
         id: crypto.randomUUID(),
         type: 'character',
         content: line.replace(/\s*\(CONT'D\)$/, ''), // Clean up extensions
         sceneId: currentScene?.id,
         sequence: elementSequence++
       };
       elements.push(charEl);

       // Look ahead for dialogue
       // Fountain allows dialogue immediately after character
       // or parentheticals
       lastLineWasBlank = false;
       continue;
    }

    // 4. PARENTHETICAL
    if (line.startsWith('(') && line.endsWith(')')) {
       const el: ScriptElement = {
         id: crypto.randomUUID(),
         type: 'parenthetical',
         content: line,
         sceneId: currentScene?.id,
         sequence: elementSequence++
       };
       elements.push(el);
       lastLineWasBlank = false;
       continue;
    }

    // 5. DIALOGUE (If preceding element was Character or Parenthetical)
    const prevType = elements.length > 0 ? elements[elements.length - 1].type : null;
    if (prevType === 'character' || prevType === 'parenthetical') {
       const el: ScriptElement = {
         id: crypto.randomUUID(),
         type: 'dialogue',
         content: line,
         sceneId: currentScene?.id,
         sequence: elementSequence++
       };
       elements.push(el);
       lastLineWasBlank = false;
       continue;
    }

    // 6. ACTION (Default)
    // If it's none of the above, it's action/description
    const el: ScriptElement = {
      id: crypto.randomUUID(),
      type: 'action',
      content: line,
      sceneId: currentScene?.id,
      sequence: elementSequence++
    };
    elements.push(el);
    
    // Append to scene action notes for quick reference
    if (currentScene) {
       currentScene.actionNotes += (currentScene.actionNotes ? '\n' : '') + line;
    }

    lastLineWasBlank = false;
  }

  // Link elements to scenes in the return object if needed, 
  // though we primarily use the flat list in the project.
  
  return {
    scenes,
    elements,
    metadata
  };
}
