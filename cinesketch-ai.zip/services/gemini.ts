/*
 * 🧠 SERVICE: GEMINI AI (The Artist)
 * 
 * This file handles all the conversations with Google's AI.
 * It's responsible for taking your text descriptions, sketches, and reference photos
 * and sending them to the "Gemini" or "Imagen" models to get a picture back.
 */

import { GoogleGenAI } from "@google/genai";
import { Shot, Project, Character, Outfit } from '../types';

// Helper to check for API Key
export const hasApiKey = () => !!process.env.API_KEY;

const getClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found. Please set process.env.API_KEY.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Detailed Cinematic Mappings
const SHOT_TYPE_PROMPTS: Record<string, string> = {
  "Extreme Wide Shot": "Extreme Wide Shot: Subject is barely visible, emphasizing the vast scale of the environment and landscape.",
  "Wide Shot": "Wide Shot: Subject at a distance showing full body and surrounding environment from head to toe.",
  "Medium Shot": "Medium Shot: Frame subject from waist up, showing upper body and facial expressions.",
  "Close-Up": "Close-Up: Tight framing on subject's face from shoulders to top of head, capturing detailed emotion.",
  "Extreme Close-Up": "Extreme Close-Up: Macro focus on a specific detail (eyes, mouth, or object), filling the frame.",
  "Dutch Angle": "Dutch Angle: Tilted camera axis creating a sense of unease, disorientation, or dynamic tension.",
  "Over the Shoulder": "Over the Shoulder: Camera positioned behind one character, looking past their shoulder at the subject.",
  "Birds Eye View": "Birds Eye View: High-angle shot looking directly down on the subject/scene from above."
};

// --- PROMPT CONSTRUCTOR ---
// Used for both generation and preview
export const constructPrompt = (
  shot: Shot, 
  project: Project, 
  activeCharacters: Character[],
  activeOutfits: Outfit[],
  aspectRatio: string
): string => {
  let prompt = `Cinematic movie frame. `;
  
  // A. Style Strength & Global Settings
  const styleStrength = shot.styleStrength !== undefined ? shot.styleStrength : 100;
  let styleInstruction = "";

  if (styleStrength >= 100) {
      styleInstruction = "Apply project style strictly.";
  } else if (styleStrength >= 75) {
      styleInstruction = `Apply ${project.settings.cinematicStyle} with strong influence.`;
  } else if (styleStrength >= 50) {
      styleInstruction = `Apply ${project.settings.cinematicStyle} with moderate influence.`;
  } else if (styleStrength >= 25) {
      styleInstruction = `Apply ${project.settings.cinematicStyle} subtly.`;
  } else {
      styleInstruction = `Minimal ${project.settings.cinematicStyle} influence. Prioritize scene description.`;
  }

  prompt += `Visual Style: ${project.settings.cinematicStyle} (${styleInstruction}). `;
  prompt += `Time Period/Era: ${project.settings.era}. Ensure all costumes, props, architecture, and environmental details are historically accurate to this period. `;
  prompt += `Lighting Setup: ${project.settings.lighting}. `;

  // B. Time of Day Override
  const timeSetting = (shot.timeOfDay && shot.timeOfDay !== 'Use Project Default') 
      ? shot.timeOfDay 
      : project.settings.timeOfDay;
  prompt += `Time of Day: ${timeSetting}. `;
  
  // C. Camera Specification
  const shotInstruction = SHOT_TYPE_PROMPTS[shot.shotType] || `Camera Shot: ${shot.shotType}`;
  prompt += `${shotInstruction}. `;
  
  // D. Scene Description
  if (shot.description) {
    prompt += `ACTION/SUBJECT: ${shot.description}. `;
  } else {
    prompt += `Scene: A cinematic shot matching the style. `;
  }

  // E. Character Details
  if (activeCharacters.length > 0) {
    prompt += `CHARACTERS: `;
    activeCharacters.forEach(char => {
      const outfit = activeOutfits.find(o => o.characterId === char.id);
      prompt += `[${char.name}: ${char.description}`;
      if (outfit) {
        prompt += ` wearing ${outfit.description}`;
      } else {
        prompt += ` (wearing era-appropriate attire)`;
      }
      prompt += `]. `;
    });

    // Character Positioning Hints
    if (activeCharacters.length === 1) {
        prompt += " Position character in the center of the frame.";
    } else if (activeCharacters.length === 2) {
        prompt += " Position characters with balanced spacing across the frame (left and right).";
    } else {
        prompt += " Position characters with balanced composition across the frame, ensuring all are visible and properly spaced.";
    }
  }

  // F. Quality & Negative Constraints
  prompt += `\nRENDER SETTINGS: Render in 8K quality with cinematic color grading, professional cinematography, sharp focus, film grain, and volumetric lighting.`;
  
  prompt += `\nNEGATIVE PROMPT: Do not include: text overlays, watermarks, UI elements, logos, subtitles, or low-quality artifacts.`;
  if (shot.negativePrompt) {
      prompt += ` ${shot.negativePrompt}`;
  }

  // Aspect Ratio Enforcement
  let finalAspectRatio = aspectRatio;
  let isHandled = false;

  // Handle special case: Match Reference
  if (aspectRatio === 'Match Reference') {
    // Only enforce if reference image exists
    if (shot.referenceImage) {
      prompt += ` CRITICAL ASPECT RATIO: Match the exact aspect ratio and dimensions of the provided reference image. Do not crop, letterbox, or alter the proportions in any way.\n\n`;
      isHandled = true;
    } else {
      // Fallback to project default if no reference
      finalAspectRatio = project.settings.aspectRatio;
    }
  }

  // Standard aspect ratios - ultra-strict enforcement
  if (!isHandled) {
    prompt += ` CRITICAL ASPECT RATIO ENFORCEMENT: Generate image in STRICT ${finalAspectRatio} aspect ratio format.\n`;
    
    // Add ratio-specific dimensional guidance
    switch(finalAspectRatio) {
      case '2.35:1':
        prompt += ` This is Anamorphic CinemaScope format (2.35:1). Width MUST be 2.35 times the height. Common resolutions: 2048×871, 1920×817. Do not deviate from 2.35:1 proportions.\n`;
        break;
      case '2.39:1':
        prompt += ` This is Ultra Panavision 70 format (2.39:1). Width MUST be 2.39 times the height. Common resolutions: 2048×857, 1920×803. Do not deviate from 2.39:1 proportions.\n`;
        break;
      case '21:9':
        prompt += ` This is Ultra Wide format (21:9 or 2.33:1). Width MUST be 2.33 times the height. Common resolutions: 2560×1080, 3440×1440. Maintain exact 21:9 proportions.\n`;
        break;
      case '16:9':
        prompt += ` This is Standard HD format (16:9). Width MUST be 1.78 times the height. Common resolutions: 1920×1080, 3840×2160. Maintain exact 16:9 proportions.\n`;
        break;
      case '9:16':
        prompt += ` This is Vertical/Mobile format (9:16). Height MUST be 1.78 times the width. Common resolutions: 1080×1920, 2160×3840. Maintain exact 9:16 proportions.\n`;
        break;
      case '4:3':
        prompt += ` This is Classic TV format (4:3). Width MUST be 1.33 times the height. Common resolutions: 1024×768, 1600×1200. Maintain exact 4:3 proportions.\n`;
        break;
      case '3:4':
        prompt += ` This is Vertical Classic format (3:4). Height MUST be 1.33 times the width. Common resolutions: 768×1024, 1200×1600. Maintain exact 3:4 proportions.\n`;
        break;
      case '1:1':
        prompt += ` This is Square format (1:1). Width and height MUST be identical. Common resolutions: 1080×1080, 2048×2048. Maintain perfect square proportions.\n`;
        break;
    }
    
    prompt += ` Do not crop, letterbox, pillarbox, or alter the ${finalAspectRatio} frame dimensions in any way. The entire image must conform to ${finalAspectRatio} exactly.\n\n`;
  }

  // Final Lighting Check
  prompt += ` FINAL LIGHTING CHECK: Ensure ${project.settings.lighting} is applied consistently throughout the image. Maintain proper light direction and shadow consistency.`;

  // --- Multimodal Logic (Text Additions) ---
  if (shot.sketchImage) {
      prompt += " (SKETCH COMPOSITION REFERENCE: The uploaded sketch indicates desired camera angle, subject positioning, and overall composition layout. Match this composition exactly while rendering in photorealistic quality with proper lighting, detail, and textures. The sketch is a blueprint for framing only—render final output as a real photograph.)";
  }

  if (shot.referenceImage) {
      const strength = shot.referenceStrength !== undefined ? shot.referenceStrength : 50;
      let strengthInstruction = "";
      
      if (strength >= 75) strengthInstruction = "CRITICAL: Match reference image structure exactly. Do not deviate.";
      else if (strength >= 50) strengthInstruction = "Closely follow reference composition and layout.";
      else if (strength >= 25) strengthInstruction = "Use reference as loose inspiration.";
      else strengthInstruction = "Reference for context only.";

      if (shot.controlType === 'canny') {
          prompt += ` (REFERENCE INSTRUCTION: ${strengthInstruction} Use the provided reference image as a Canny edge map guide for structure.)`;
      } else {
          prompt += ` (REFERENCE INSTRUCTION: ${strengthInstruction} Use the provided reference image as a structural depth map guide.)`;
      }
  }

  const hasReferencePhotos = activeCharacters.some(c => c.referencePhotos && c.referencePhotos.length > 0) || activeOutfits.some(o => o.referencePhotos && o.referencePhotos.length > 0);
  if (hasReferencePhotos) {
      prompt += " Match facial features, hair, skin tone, and clothing EXACTLY as shown in reference photos. Maintain strict visual consistency.";
  }

  return prompt;
};

// --- GENERATE SINGLE IMAGE ---
export const generateShotImage = async (
  shot: Shot, 
  project: Project, 
  activeCharacters: Character[],
  activeOutfits: Outfit[],
  options: { model: string; aspectRatio: string; imageSize?: string }
): Promise<string> => {
  const ai = getClient();
  
  // 1. Construct Prompt using shared logic
  let prompt = constructPrompt(shot, project, activeCharacters, activeOutfits, options.aspectRatio);

  // --- DEBUG LOGGING ---
  console.group("🎨 GENERATING PROMPT");
  console.log("TEXT PROMPT:", prompt);
  console.log("SETTINGS:", {
      model: options.model,
      aspectRatio: options.aspectRatio,
      styleStrength: shot.styleStrength,
      timeOverride: shot.timeOfDay,
      negative: shot.negativePrompt
  });
  console.groupEnd();

  try {
    const contents: any = { parts: [] };

    // A. Add Character Reference Photos
    activeCharacters.forEach(char => {
      if (char.referencePhotos && char.referencePhotos.length > 0) {
          char.referencePhotos.forEach(photo => {
            const match = photo.match(/^data:(.+);base64,(.+)$/);
            if (match) {
              contents.parts.push({ inlineData: { mimeType: match[1], data: match[2] } });
            }
          });
      }
    });

    // B. Add Outfit Reference Photos
    activeOutfits.forEach(outfit => {
      if (outfit.referencePhotos && outfit.referencePhotos.length > 0) {
          outfit.referencePhotos.forEach(photo => {
            const match = photo.match(/^data:(.+);base64,(.+)$/);
            if (match) {
              contents.parts.push({ inlineData: { mimeType: match[1], data: match[2] } });
            }
          });
      }
    });

    // C. Add Sketch
    if (shot.sketchImage) {
      const base64Data = shot.sketchImage.split(',')[1] || shot.sketchImage;
      const mimeMatch = shot.sketchImage.match(/^data:(.+);base64,/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
      contents.parts.push({ inlineData: { mimeType: mimeType, data: base64Data } });
    }

    // D. Reference Image Control (Depth/Canny)
    if (shot.referenceImage) {
      const refBase64 = shot.referenceImage.split(',')[1] || shot.referenceImage;
      const mimeMatch = shot.referenceImage.match(/^data:(.+);base64,/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
      contents.parts.push({ inlineData: { mimeType: mimeType, data: refBase64 } });
    }
    
    // Add text prompt
    contents.parts.push({ text: prompt });

    // F. Configuration
    const imageConfig: any = { aspectRatio: options.aspectRatio !== 'Match Reference' ? options.aspectRatio : undefined };
    
    // Pass imageSize if using Pro model which supports it
    if (options.model.includes('gemini-3') && options.imageSize) {
        // Simple config often works better across SDK versions
    }

    const response = await ai.models.generateContent({
      model: options.model,
      contents: contents,
      config: { imageConfig: imageConfig }
    });

    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("No image generated from Gemini.");

  } catch (error: any) {
    console.error("Gemini Image Gen Error:", error);
    if (error.message?.includes('403') || error.status === 403) {
      throw new Error(`Permission Denied. Please try using 'Gemini (Fast)' for this request.`);
    }
    throw error;
  }
};

// --- BATCH GENERATION ---
export const generateBatchShotImages = async (
  shot: Shot,
  project: Project,
  activeCharacters: Character[],
  activeOutfits: Outfit[],
  options: { model: string; aspectRatio: string; imageSize?: string },
  count: number = 1
): Promise<string[]> => {
    const promises = Array(count).fill(null).map(() => 
        generateShotImage(shot, project, activeCharacters, activeOutfits, options)
    );
    try {
        const results = await Promise.all(promises);
        return results;
    } catch (error) {
        console.error("Batch Generation Error:", error);
        throw error;
    }
};

// --- SKETCH ANALYSIS ---
export const analyzeSketch = async (sketchBase64: string): Promise<string> => {
    const ai = getClient();
    try {
        const base64Data = sketchBase64.split(',')[1] || sketchBase64;
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: base64Data } },
                    { text: "Analyze this storyboard sketch. Briefly describe the camera angle, subject position, and implied action in 2 sentences." }
                ]
            }
        });
        return response.text || "";
    } catch (error) {
        console.error("Sketch Analysis Error", error);
        return "";
    }
};