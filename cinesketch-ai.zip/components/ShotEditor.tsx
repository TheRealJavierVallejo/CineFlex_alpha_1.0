
/*
 * 🎨 COMPONENT: SHOT EDITOR (Studio Layout)
 * Commercial Quality Update: Teal Theme & Studio Classes
 */

import React, { useState, useEffect, useRef } from 'react';
import { Shot, Project, Character, Outfit, ShowToastFn } from '../types';
import { generateShotImage, generateBatchShotImages, analyzeSketch, constructPrompt } from '../services/gemini';
import { SHOT_TYPES, MODEL_OPTIONS, ASPECT_RATIOS, IMAGE_RESOLUTIONS, VARIATION_COUNTS, TIMES_OF_DAY } from '../constants';
import { Wand2, Image as ImageIcon, Upload, Loader2, X, Maximize2, Trash2, RotateCcw, Ban, Info, HelpCircle, Eye, Copy } from 'lucide-react';
import { getCharacters, getOutfits } from '../services/storage';
import { VariationPicker } from './VariationPicker';

interface ShotEditorProps {
  project: Project;
  onUpdateShot: (shot: Shot) => void;
  onClose: () => void;
  activeShot: Shot | null;
  showToast: ShowToastFn;
}

type EditorTab = 'details' | 'camera' | 'cast';

export const ShotEditor: React.FC<ShotEditorProps> = ({ project, onUpdateShot, onClose, activeShot, showToast }) => {
  // --- STATE ---
  const [shot, setShot] = useState<Shot>(activeShot || {
    id: crypto.randomUUID(),
    sequence: project.shots.length + 1,
    description: '',
    notes: '',
    characterIds: [],
    shotType: 'Wide Shot',
    aspectRatio: project.settings.aspectRatio || '16:9',
    model: MODEL_OPTIONS[0].value,
    imageSize: '1K',
    generationCandidates: [],
    generationInProgress: false,
    controlType: 'depth',
    referenceStrength: 50,
    timeOfDay: undefined,
    negativePrompt: '',
    styleStrength: 100
  });

  const [activeTab, setActiveTab] = useState<EditorTab>('details');
  const [characters, setCharacters] = useState<Character[]>([]);
  const [outfits, setOutfits] = useState<Outfit[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const [showVariationPicker, setShowVariationPicker] = useState(false);
  const [currentCandidates, setCurrentCandidates] = useState<string[]>(shot.generationCandidates || []);
  const [showPromptPreview, setShowPromptPreview] = useState(false);
  const [detectedReferenceRatio, setDetectedReferenceRatio] = useState<string | null>(null);

  // Local Settings
  const [selectedModel, setSelectedModel] = useState(shot.model || MODEL_OPTIONS[0].value);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState(shot.aspectRatio || project.settings.aspectRatio || '16:9');
  const [variationCount, setVariationCount] = useState<number>(project.settings.variationCount || 1);
  const [selectedResolution, setSelectedResolution] = useState<string>(project.settings.imageResolution || '2048x2048');

  const containerRef = useRef<HTMLDivElement>(null);
  const descriptionRef = useRef<HTMLTextAreaElement>(null);

  const activeChars = characters.filter(c => shot.characterIds.includes(c.id));

  // --- KEYBOARD & FOCUS ---
  useEffect(() => {
    if (descriptionRef.current) {
        descriptionRef.current.focus();
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
          if (showPromptPreview) setShowPromptPreview(false);
          else onClose();
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') handleGenerate();
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showPromptPreview]);

  // Load assets
  useEffect(() => {
    const loadAssets = async () => {
        const [chars, outfs] = await Promise.all([
            getCharacters(project.id),
            getOutfits(project.id)
        ]);
        setCharacters(chars);
        setOutfits(outfs);
    };
    loadAssets();
  }, [project.id]);

  // Sync settings
  useEffect(() => {
    setShot(prev => ({ 
        ...prev, 
        model: selectedModel, 
        aspectRatio: selectedAspectRatio,
        imageSize: selectedResolution
    }));
  }, [selectedModel, selectedAspectRatio, selectedResolution]);

  // Aspect Ratio Detection
  const getImageAspectRatio = (imageUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const ratio = (img.width / img.height).toFixed(2);
        const width = img.width;
        const height = img.height;
        if (Math.abs(Number(ratio) - 1.78) < 0.05) resolve('16:9');
        else if (Math.abs(Number(ratio) - 2.35) < 0.05) resolve('2.35:1');
        else if (Math.abs(Number(ratio) - 2.39) < 0.05) resolve('2.39:1');
        else if (Math.abs(Number(ratio) - 2.33) < 0.05) resolve('21:9');
        else if (Math.abs(Number(ratio) - 1.33) < 0.05) resolve('4:3');
        else if (Math.abs(Number(ratio) - 1.0) < 0.05) resolve('1:1');
        else resolve(`${width}:${height}`);
      };
      img.onerror = () => resolve('Unknown');
      img.src = imageUrl;
    });
  };

  useEffect(() => {
    if (shot.referenceImage && selectedAspectRatio === 'Match Reference') {
      getImageAspectRatio(shot.referenceImage).then(ratio => {
        setDetectedReferenceRatio(ratio);
      });
    } else {
      setDetectedReferenceRatio(null);
    }
  }, [shot.referenceImage, selectedAspectRatio]);

  // --- HANDLERS ---
  const handleSketchUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        setShot(prev => ({ ...prev, sketchImage: base64 }));
        setIsAnalyzing(true);
        showToast("Analyzing sketch...", 'info');
        const analysis = await analyzeSketch(base64);
        if (analysis) {
            setShot(prev => ({...prev, description: prev.description ? prev.description + " " + analysis : analysis}));
            showToast("Sketch analysis added", 'success');
        }
        setIsAnalyzing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReferenceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setShot(prev => ({ 
            ...prev, 
            referenceImage: reader.result as string,
            controlType: prev.controlType || 'depth',
            referenceStrength: prev.referenceStrength || 50
        }));
        showToast("Reference image added", 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetDefaults = () => {
    setShot(prev => ({
        ...prev,
        styleStrength: 100,
        timeOfDay: undefined,
        negativePrompt: ''
    }));
    showToast("Advanced settings reset to defaults", 'success');
  };

  const handleGenerate = async () => {
    if (!shot.description?.trim() && !shot.sketchImage) {
        showToast("Please add a scene description or upload a sketch before rendering.", 'warning');
        return;
    }
    const hasMissingPhotos = activeChars.some(c => !c.referencePhotos || c.referencePhotos.length === 0);
    if (activeChars.length > 0 && hasMissingPhotos) {
        showToast("Warning: Selected characters have no reference photos.", 'warning');
    }

    setIsGenerating(true);
    showToast("Starting render...", 'info');
    
    try {
      if (variationCount > 1) {
          const images = await generateBatchShotImages(shot, project, activeChars, outfits, {
              model: selectedModel,
              aspectRatio: selectedAspectRatio,
              imageSize: selectedResolution
          }, variationCount);
          setCurrentCandidates(images);
          setShowVariationPicker(true);
          onUpdateShot({ ...shot, generationCandidates: images });
          showToast("Batch complete", 'success');
      } else {
          const img = await generateShotImage(shot, project, activeChars, outfits, {
            model: selectedModel,
            aspectRatio: selectedAspectRatio,
            imageSize: selectedResolution
          });
          const updated = { ...shot, generatedImage: img, generationCandidates: [img] };
          setShot(updated);
          onUpdateShot(updated);
          showToast("Render successful", 'success');
      }
    } catch (e) {
      showToast("Render failed", 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectVariation = (image: string) => {
      const updated = { ...shot, generatedImage: image, generationCandidates: currentCandidates };
      setShot(updated);
      onUpdateShot(updated);
      setShowVariationPicker(false);
      showToast("Variation selected", 'success');
  };

  const handleSave = () => {
    onUpdateShot(shot);
    onClose();
    showToast("Shot saved", 'success');
  };

  const handleCopyPrompt = () => {
    const txt = constructPrompt(shot, project, activeChars, outfits, selectedAspectRatio);
    navigator.clipboard.writeText(txt);
    showToast("Prompt copied to clipboard", 'success');
  };

  const TabButton = ({ id, label }: { id: EditorTab, label: string }) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`
        flex-1 py-3 text-sm font-medium border-b-2 transition-colors focus:outline-none
        ${activeTab === id ? 'border-primary text-text-primary' : 'border-transparent text-text-secondary hover:text-text-primary hover:bg-surface-secondary'}
      `}
      role="tab"
      aria-selected={activeTab === id}
    >
      {label}
    </button>
  );

  const getAspectRatioStyle = (ratio: string) => {
    if (ratio === 'Match Reference' && detectedReferenceRatio) {
        const [w, h] = detectedReferenceRatio.split(':').map(Number);
        if (!isNaN(w) && !isNaN(h)) return { aspectRatio: `${w}/${h}` };
    }
    if (ratio === 'Match Reference' || !ratio) {
        return { aspectRatio: '16/9' };
    }
    const [w, h] = ratio.split(':').map(Number);
    return { aspectRatio: `${w}/${h}` };
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-background/95 flex items-center justify-center backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-label="Shot Editor"
    >
      
      {showVariationPicker && (
          <VariationPicker 
             candidates={currentCandidates}
             onSelect={handleSelectVariation}
             onCancel={() => setShowVariationPicker(false)}
             onGenerateMore={handleGenerate}
             onRegenerateSlot={() => {}}
             isGeneratingMore={isGenerating}
             generatingSlotIndex={null}
          />
      )}

      {showPromptPreview && (
         <div className="fixed inset-0 z-[70] bg-black/80 flex items-center justify-center backdrop-blur-sm p-4 animate-in fade-in duration-150">
             <div className="bg-surface w-full max-w-2xl border border-border rounded-lg shadow-2xl flex flex-col max-h-[80vh]">
                 <div className="h-12 border-b border-border flex items-center justify-between px-4 bg-surface-secondary">
                     <span className="font-bold text-text-primary text-sm flex items-center gap-2">
                         <Eye className="w-4 h-4 text-primary"/> Generated Prompt Preview
                     </span>
                     <button onClick={() => setShowPromptPreview(false)} className="text-text-tertiary hover:text-text-primary" aria-label="Close Preview">
                         <X className="w-5 h-5"/>
                     </button>
                 </div>
                 <div className="p-6 overflow-y-auto bg-background">
                     {selectedAspectRatio === 'Match Reference' && (
                      <div className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-md text-xs text-primary flex items-center gap-2">
                         <Info size={14} />
                         {shot.referenceImage 
                           ? `Using reference image aspect ratio: ${detectedReferenceRatio || 'detecting...'}`
                           : `Will fall back to project default: ${project.settings.aspectRatio}`
                         }
                      </div>
                     )}
                     <pre className="whitespace-pre-wrap font-mono text-xs text-text-secondary leading-relaxed selection:bg-primary/30 selection:text-white">
                         {constructPrompt(shot, project, activeChars, outfits, selectedAspectRatio)}
                     </pre>
                 </div>
                 <div className="p-4 border-t border-border bg-surface-secondary flex justify-end">
                     <button 
                        onClick={handleCopyPrompt}
                        className="studio-btn studio-btn-secondary text-xs"
                     >
                         <Copy className="w-3 h-3"/> Copy to Clipboard
                     </button>
                 </div>
             </div>
         </div>
      )}

      <div 
        ref={containerRef}
        className="bg-surface w-[95vw] max-w-[1400px] h-[90vh] border border-border shadow-2xl rounded-xl flex overflow-hidden"
      >
        
        {/* LEFT COLUMN: CONTROLS */}
        <div className="w-[400px] flex flex-col border-r border-border bg-surface-secondary">
           <div className="h-16 border-b border-border flex items-center justify-between px-6 bg-surface">
              <div>
                <h2 className="text-text-primary font-bold text-base">Shot #{shot.sequence}</h2>
                <div className="text-text-tertiary text-xs font-mono">ID: {shot.id.substring(0,6)}</div>
              </div>
           </div>

           <div className="flex border-b border-border bg-surface px-2" role="tablist">
              <TabButton id="details" label="Description" />
              <TabButton id="camera" label="Camera & Style" />
              <TabButton id="cast" label="Cast & Assets" />
           </div>

           <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-surface">
              {activeTab === 'details' && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Prompt / Description</label>
                    <textarea 
                      ref={descriptionRef}
                      value={shot.description} onChange={e => setShot(prev => ({...prev, description: e.target.value}))}
                      className="studio-input h-40 resize-none py-3 leading-relaxed"
                      placeholder="Describe the action, subject, and environment..."
                    />
                  </div>

                  <div className="group">
                    <div className="flex items-center gap-2 mb-2">
                       <label className="block text-xs font-bold text-text-secondary uppercase">Negative Prompt (Optional)</label>
                       <div className="relative group/tooltip">
                          <HelpCircle className="w-3 h-3 text-text-tertiary cursor-help" />
                       </div>
                    </div>
                    <div className="relative">
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary">
                            <Ban className="w-4 h-4" />
                        </div>
                        <input 
                          value={shot.negativePrompt || ''} 
                          onChange={e => setShot(prev => ({...prev, negativePrompt: e.target.value}))}
                          className="studio-input pl-10"
                          placeholder="e.g., blurry, low quality, text"
                        />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Technical Notes</label>
                    <input 
                      value={shot.notes} onChange={e => setShot(prev => ({...prev, notes: e.target.value}))}
                      className="studio-input"
                      placeholder="Lighting cues, camera movement..."
                    />
                  </div>
                  
                  <div className="pt-4 border-t border-border">
                    <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Composition Reference</label>
                    <div className="flex gap-3">
                       <div 
                          className="w-24 h-24 bg-background border-2 border-dashed border-border rounded-lg flex items-center justify-center relative group hover:border-text-secondary transition-colors cursor-pointer overflow-hidden"
                          onClick={() => document.getElementById('sketch-upload')?.click()}
                       >
                          {shot.sketchImage ? (
                             <img src={shot.sketchImage} className="w-full h-full object-contain p-1" alt="Sketch" />
                          ) : <Upload className="w-5 h-5 text-text-tertiary" aria-hidden="true" />}
                          <input id="sketch-upload" type="file" onChange={handleSketchUpload} className="hidden" />
                       </div>
                       <div className="flex-1 text-xs text-text-tertiary py-1">
                          <p className="mb-1">Upload a rough sketch or storyboard frame.</p>
                          {isAnalyzing && <div className="flex items-center gap-2 text-primary"><Loader2 className="w-3 h-3 animate-spin"/> Analyzing layout...</div>}
                       </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'camera' && (
                 <div className="space-y-8">
                    <div className="space-y-4">
                        <div className="text-[10px] font-bold text-text-tertiary uppercase tracking-wider border-b border-border pb-1">Framing & Resolution</div>
                        <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Aspect Ratio</label>
                              <select 
                                 value={selectedAspectRatio} onChange={(e) => setSelectedAspectRatio(e.target.value)}
                                 className="studio-input text-sm"
                              >
                                 {ASPECT_RATIOS.map(r => <option key={r} value={r}>{r}</option>)}
                              </select>
                              
                              {selectedAspectRatio === 'Match Reference' && !shot.referenceImage && (
                                <div className="mt-2 p-2 bg-warning/10 border border-warning/20 rounded text-xs text-warning flex items-center gap-2">
                                  <Info size={12} /> Upload ref image below.
                                </div>
                              )}
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Resolution</label>
                              <select 
                                 value={selectedResolution} onChange={(e) => setSelectedResolution(e.target.value)}
                                 className="studio-input text-sm"
                              >
                                 {IMAGE_RESOLUTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                              </select>
                           </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-text-secondary uppercase mb-2">Shot Type</label>
                            <div className="flex flex-wrap gap-2">
                               {SHOT_TYPES.map(t => (
                                   <button 
                                      key={t} 
                                      onClick={() => setShot(prev => ({...prev, shotType: t}))}
                                      className={`px-3 py-1.5 rounded text-xs font-medium transition-all border ${shot.shotType === t ? 'bg-primary text-white border-primary shadow-md' : 'bg-background border-border text-text-secondary hover:border-text-tertiary'}`}
                                   >
                                      {t}
                                   </button>
                               ))}
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="text-[10px] font-bold text-text-tertiary uppercase tracking-wider border-b border-border pb-1">Environment</div>
                        <div className="group">
                            <div className="flex items-center gap-2 mb-2">
                                <label className="block text-xs font-bold text-text-secondary uppercase">Time of Day</label>
                            </div>
                            <select 
                                 value={shot.timeOfDay || ''} 
                                 onChange={(e) => setShot(prev => ({...prev, timeOfDay: e.target.value === '' ? undefined : e.target.value}))}
                                 className={`studio-input text-sm transition-colors ${shot.timeOfDay ? 'border-primary text-primary' : ''}`}
                            >
                                 <option value="" className="text-text-tertiary">Use Project Default ({project.settings.timeOfDay})</option>
                                 {TIMES_OF_DAY.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="text-[10px] font-bold text-text-tertiary uppercase tracking-wider border-b border-border pb-1">Style Influence</div>
                        <div className="bg-surface-secondary p-4 rounded-lg border border-border">
                             <div className="flex justify-between mb-4">
                                 <label className="text-xs font-bold text-text-secondary uppercase">Intensity</label>
                                 <span className="text-xs font-mono text-primary font-bold">{shot.styleStrength ?? 100}%</span>
                             </div>
                             
                             <div className="relative h-6 flex items-center select-none">
                                 <div className="absolute w-full h-1.5 rounded-full bg-gradient-to-r from-border via-primary/50 to-primary"></div>
                                 <input 
                                    type="range" min="0" max="100" 
                                    value={shot.styleStrength ?? 100}
                                    onChange={(e) => setShot(prev => ({...prev, styleStrength: parseInt(e.target.value)}))}
                                    className="w-full h-6 absolute opacity-0 cursor-pointer z-10"
                                 />
                                 <div 
                                    className="w-4 h-4 bg-white border-2 border-primary rounded-full shadow-lg pointer-events-none absolute"
                                    style={{ left: `calc(${shot.styleStrength ?? 100}% - 8px)` }}
                                 ></div>
                             </div>
                        </div>

                        <div className="flex justify-end pt-2">
                            <button
                                onClick={handleResetDefaults}
                                className="studio-btn studio-btn-secondary text-xs h-8 px-3"
                            >
                                <RotateCcw className="w-3 h-3" /> Reset Defaults
                            </button>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="text-[10px] font-bold text-text-tertiary uppercase tracking-wider border-b border-border pb-1">ControlNet</div>
                        <div className="flex gap-3 items-center">
                            <div className="w-20 h-20 bg-background border-2 border-dashed border-border rounded-lg flex items-center justify-center relative group hover:border-primary transition-colors overflow-hidden">
                                {shot.referenceImage ? (
                                    <>
                                      <img src={shot.referenceImage} className="w-full h-full object-cover" alt="Reference" />
                                      <button onClick={() => setShot(prev => ({...prev, referenceImage: undefined}))} className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white"><Trash2 className="w-4 h-4"/></button>
                                    </>
                                ) : <Upload className="w-4 h-4 text-text-tertiary" />}
                                <input type="file" onChange={handleReferenceUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                            </div>
                            <div className="flex-1 space-y-2">
                                <div className="flex bg-background rounded p-0.5 border border-border w-fit">
                                   {['depth', 'canny'].map(t => (
                                       <button key={t} onClick={() => setShot(prev => ({...prev, controlType: t as any}))} className={`px-2 py-0.5 text-[10px] uppercase rounded ${shot.controlType === t ? 'bg-primary text-white' : 'text-text-tertiary'}`}>{t}</button>
                                   ))}
                                </div>
                                <input 
                                   type="range" 
                                   value={shot.referenceStrength || 50} 
                                   onChange={(e) => setShot(prev => ({...prev, referenceStrength: parseInt(e.target.value)}))}
                                   className="w-full h-1 bg-border rounded-lg appearance-none cursor-pointer accent-primary" 
                                />
                            </div>
                        </div>
                    </div>
                 </div>
              )}

              {activeTab === 'cast' && (
                 <div className="space-y-4">
                    <div className="text-xs text-text-secondary mb-2">Select characters to include in the scene.</div>
                    {characters.map(char => (
                        <div 
                           key={char.id}
                           onClick={() => {
                               const ids = shot.characterIds.includes(char.id) 
                                   ? shot.characterIds.filter(id => id !== char.id) 
                                   : [...shot.characterIds, char.id];
                               setShot(prev => ({...prev, characterIds: ids}));
                           }}
                           className={`
                              flex items-center p-3 rounded-lg border cursor-pointer transition-all
                              ${shot.characterIds.includes(char.id) ? 'bg-primary/10 border-primary' : 'bg-background border-border hover:border-text-secondary'}
                           `}
                        >
                           <div className={`w-4 h-4 rounded-full border mr-3 flex items-center justify-center ${shot.characterIds.includes(char.id) ? 'border-primary bg-primary' : 'border-text-tertiary'}`}>
                              {shot.characterIds.includes(char.id) && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                           </div>
                           <span className={`font-medium text-sm ${shot.characterIds.includes(char.id) ? 'text-text-primary' : 'text-text-secondary'}`}>{char.name}</span>
                        </div>
                    ))}
                    {characters.length === 0 && <div className="text-center text-text-tertiary py-4">No characters in project.</div>}
                 </div>
              )}
           </div>
        </div>

        {/* RIGHT COLUMN: PREVIEW */}
        <div className="flex-1 bg-[#121212] flex flex-col relative">
            <div className="h-16 border-b border-border flex items-center justify-between px-6 shrink-0">
               <div className="flex items-center gap-4">
                   <div className="flex items-center gap-2">
                      <label className="text-xs font-bold text-text-secondary uppercase">Variations:</label>
                      <div className="flex bg-surface-secondary rounded border border-border p-0.5">
                          {[1, 2, 4].map(v => (
                             <button 
                                key={v}
                                onClick={() => setVariationCount(v)}
                                className={`w-8 h-6 text-xs font-medium rounded ${variationCount === v ? 'bg-primary text-white' : 'text-text-tertiary'}`}
                             >
                                {v}
                             </button>
                          ))}
                      </div>
                   </div>
                   <div className="flex items-center gap-2">
                      <label className="text-xs font-bold text-text-secondary uppercase">Model:</label>
                      <select 
                         value={selectedModel} onChange={(e) => setSelectedModel(e.target.value)}
                         className="bg-surface-secondary border border-border h-7 text-xs text-text-secondary rounded px-2 outline-none focus:border-primary"
                      >
                         {MODEL_OPTIONS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                      </select>
                   </div>
                   <button 
                      onClick={() => setShowPromptPreview(true)}
                      className="p-1.5 hover:bg-surface-secondary rounded text-text-tertiary hover:text-text-primary transition-colors"
                      title="Preview Generated Prompt"
                   >
                       <Eye className="w-4 h-4" />
                   </button>
               </div>
               <button onClick={onClose} className="p-2 hover:bg-surface-secondary rounded-full text-text-tertiary hover:text-text-primary transition-colors">
                  <X className="w-5 h-5" />
               </button>
            </div>

            <div className="flex-1 flex items-center justify-center p-8 overflow-hidden bg-[#0a0a0a]">
               <div className="relative w-full max-w-4xl flex items-center justify-center shadow-2xl" style={{ maxHeight: '100%' }}>
                   <div className="relative bg-black border border-border group rounded-sm overflow-hidden" style={{ ...getAspectRatioStyle(selectedAspectRatio), width: '100%', maxHeight: '70vh' }}>
                      {shot.generatedImage ? (
                          <img src={shot.generatedImage} className="w-full h-full object-contain" alt="Rendered Shot" />
                      ) : (
                          <div className="absolute inset-0 flex flex-col items-center justify-center text-border">
                              {isGenerating ? (
                                  <div className="flex flex-col items-center gap-3 animate-pulse">
                                      <Loader2 className="w-10 h-10 animate-spin text-primary" />
                                      <div className="text-xs font-mono text-primary">RENDERING...</div>
                                  </div>
                              ) : (
                                  <>
                                    <ImageIcon className="w-16 h-16 mb-4 opacity-20" />
                                    <div className="text-sm font-mono opacity-40">NO RENDER AVAILABLE</div>
                                  </>
                              )}
                          </div>
                      )}

                      {shot.generatedImage && (
                          <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                              <button className="p-2 bg-black/50 hover:bg-primary text-white rounded backdrop-blur-sm transition-colors" aria-label="Maximize">
                                  <Maximize2 className="w-4 h-4" />
                              </button>
                              <a href={shot.generatedImage} download={`shot_${shot.sequence}.png`} className="p-2 bg-black/50 hover:bg-primary text-white rounded backdrop-blur-sm transition-colors" aria-label="Download Image">
                                  <Upload className="w-4 h-4 rotate-180" />
                              </a>
                          </div>
                      )}
                   </div>
               </div>
            </div>

            <div className="h-20 border-t border-border bg-surface flex items-center justify-between px-8 shrink-0">
                <div className="text-xs text-text-tertiary">
                    {isGenerating ? "Generating high-fidelity assets..." : "Ready to render."}
                </div>
                <div className="flex gap-4">
                    <button onClick={onClose} className="studio-btn studio-btn-secondary border-transparent hover:bg-surface-secondary">
                       Cancel
                    </button>
                    <button onClick={handleSave} className="studio-btn studio-btn-secondary">
                       Save Changes
                    </button>
                    <div className="relative group/btn-tooltip">
                        <button 
                           onClick={handleGenerate}
                           disabled={isGenerating || (!shot.description?.trim() && !shot.sketchImage)}
                           className="studio-btn studio-btn-primary shadow-lg shadow-teal-900/20 px-8 disabled:opacity-50"
                        >
                           {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                           RENDER SHOT
                        </button>
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};
