
/*
 * 📜 COMPONENT: SCRIPT ELEMENT CARD
 * Commercial Quality Update
 */

import React from 'react';
import { ScriptElement, Shot } from '../types';
import { Film, X, Link as LinkIcon } from 'lucide-react';

interface ScriptElementCardProps {
  element: ScriptElement;
  linkedShots: Shot[];
  onLinkShot: (elementId: string) => void;
  onUnlinkShot: (elementId: string, shotId: string) => void;
}

export const ScriptElementCard: React.FC<ScriptElementCardProps> = ({
  element,
  linkedShots,
  onLinkShot,
  onUnlinkShot
}) => {

  const getStyles = () => {
    switch (element.type) {
      case 'scene_heading':
        return {
          container: 'bg-[#2A3F5F] border-[#3A5F5F]',
          text: 'text-white font-bold text-sm uppercase font-mono p-3'
        };
      case 'action':
        return {
          container: 'bg-surface-secondary border-border',
          text: 'text-text-primary text-xs p-3'
        };
      case 'dialogue':
        return {
          container: 'bg-surface border-border ml-10',
          text: 'text-text-primary text-xs italic p-3'
        };
      case 'character':
        return {
          container: 'bg-surface-secondary border-border',
          text: 'text-text-primary font-bold text-xs uppercase text-center p-3'
        };
      case 'parenthetical':
        return {
          container: 'bg-surface border-border ml-20',
          text: 'text-text-secondary text-[11px] italic p-1 px-2'
        };
      case 'transition':
        return {
          container: 'bg-surface-secondary border-border',
          text: 'text-text-tertiary font-bold text-[11px] uppercase text-right p-3'
        };
      default:
        return {
          container: 'bg-surface-secondary border-border',
          text: 'text-text-primary text-xs p-3'
        };
    }
  };

  const styles = getStyles();

  return (
    <div className={`mb-2 rounded-lg border ${styles.container} shadow-sm`}>
      <div className={styles.text}>
        {element.content}
      </div>

      {linkedShots.length > 0 && (
        <div className="mt-3 pt-3 border-t border-border px-3 pb-2">
          <div className="flex gap-2 flex-wrap">
            {linkedShots.map(shot => (
              <div key={shot.id} className="relative group">
                <div className="w-[60px] h-[40px] bg-background border border-border rounded-md overflow-hidden">
                  {shot.generatedImage ? (
                    <img
                      src={shot.generatedImage}
                      className="w-full h-full object-cover"
                      alt={`Shot ${shot.sequence}`}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Film className="w-4 h-4 text-text-tertiary" />
                    </div>
                  )}
                </div>

                <button
                  onClick={() => onUnlinkShot(element.id, shot.id)}
                  className="absolute -top-1 -right-1 bg-surface border border-border rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity text-text-primary"
                  aria-label="Unlink shot"
                >
                  <X className="w-3 h-3" />
                </button>

                <div className="text-[9px] text-text-tertiary text-center mt-0.5 font-mono">
                  SHOT #{shot.sequence}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="px-3 pb-2 pt-2">
        <button
          onClick={() => onLinkShot(element.id)}
          className="w-full text-xs px-3 py-1.5 bg-primary/5 hover:bg-primary/10 text-primary border border-primary/20 rounded-md flex items-center justify-center gap-1.5 transition-colors font-medium"
        >
          <LinkIcon className="w-3 h-3" />
          Link Shot
        </button>
      </div>
    </div>
  );
};
