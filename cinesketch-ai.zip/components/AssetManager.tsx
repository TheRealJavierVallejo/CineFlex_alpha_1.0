
/*
 * 👥 COMPONENT: ASSET MANAGER
 * Commercial Quality Update: Teal Theme & Gallery Grid
 */

import React, { useState, useEffect, useRef } from 'react';
import { Character, Outfit, ShowToastFn } from '../types';
import { getCharacters, saveCharacters, getOutfits, saveOutfits } from '../services/storage';
import { compressImage } from '../services/image';
import { Plus, Trash2, User, Shirt, Loader2, Image as ImageIcon, Upload, X } from 'lucide-react';

interface AssetManagerProps {
  projectId: string;
  showToast: ShowToastFn;
}

export const AssetManager: React.FC<AssetManagerProps> = ({ projectId, showToast }) => {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [outfits, setOutfits] = useState<Outfit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCharId, setSelectedCharId] = useState<string | null>(null);
  
  const [newCharName, setNewCharName] = useState('');
  const [newCharDesc, setNewCharDesc] = useState('');
  const [newOutfitName, setNewOutfitName] = useState('');
  const [newOutfitDesc, setNewOutfitDesc] = useState('');

  const [isUploading, setIsUploading] = useState(false);
  const [uploadTarget, setUploadTarget] = useState<{ type: 'character' | 'outfit', id: string } | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadAssets = async () => {
      setIsLoading(true);
      const [chars, outfs] = await Promise.all([
        getCharacters(projectId),
        getOutfits(projectId)
      ]);
      setCharacters(chars);
      setOutfits(outfs);
      setIsLoading(false);
    };
    loadAssets();
  }, [projectId]);

  const handleAddCharacter = async () => {
    if (!newCharName.trim()) return;
    const newChar: Character = { id: crypto.randomUUID(), name: newCharName, description: newCharDesc, referencePhotos: [] };
    const updated = [...characters, newChar];
    setCharacters(updated);
    await saveCharacters(projectId, updated);
    setNewCharName(''); setNewCharDesc('');
    showToast("Character added", 'success');
  };

  const handleDeleteCharacter = async (id: string) => {
    const charToDelete = characters.find(c => c.id === id);
    if (!charToDelete) return;

    const updated = characters.filter(c => c.id !== id);
    setCharacters(updated);
    await saveCharacters(projectId, updated);
    
    const linkedOutfits = outfits.filter(o => o.characterId === id);
    const updatedOutfits = outfits.filter(o => o.characterId !== id);
    setOutfits(updatedOutfits);
    await saveOutfits(projectId, updatedOutfits);
    
    if (selectedCharId === id) setSelectedCharId(null);
    
    showToast("Character removed", 'info', {
        label: "Undo",
        onClick: async () => {
            const restoredChars = [...updated, charToDelete];
            setCharacters(restoredChars);
            await saveCharacters(projectId, restoredChars);
            const restoredOutfits = [...updatedOutfits, ...linkedOutfits];
            setOutfits(restoredOutfits);
            await saveOutfits(projectId, restoredOutfits);
            showToast("Character restored", 'success');
        }
    });
  };

  const handleAddOutfit = async () => {
    if (!selectedCharId || !newOutfitName.trim()) return;
    const newOutfit: Outfit = { id: crypto.randomUUID(), characterId: selectedCharId, name: newOutfitName, description: newOutfitDesc, referencePhotos: [] };
    const updated = [...outfits, newOutfit];
    setOutfits(updated);
    await saveOutfits(projectId, updated);
    setNewOutfitName(''); setNewOutfitDesc('');
    showToast("Outfit added", 'success');
  };

  const handleDeleteOutfit = async (id: string) => {
    const outfitToDelete = outfits.find(o => o.id === id);
    if (!outfitToDelete) return;

    const updated = outfits.filter(o => o.id !== id);
    setOutfits(updated);
    await saveOutfits(projectId, updated);
    
    showToast("Outfit removed", 'info', {
        label: "Undo",
        onClick: async () => {
            const restored = [...updated, outfitToDelete];
            setOutfits(restored);
            await saveOutfits(projectId, restored);
            showToast("Outfit restored", 'success');
        }
    });
  };

  const triggerImageUpload = (type: 'character' | 'outfit', id: string) => {
    setUploadTarget({ type, id });
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !uploadTarget) return;
    setIsUploading(true);
    try {
        const compressedBase64 = await compressImage(file);
        if (uploadTarget.type === 'character') {
            const updated = characters.map(c => c.id === uploadTarget.id ? { ...c, referencePhotos: [...(c.referencePhotos || []), compressedBase64] } : c);
            setCharacters(updated);
            await saveCharacters(projectId, updated);
        } else {
            const updated = outfits.map(o => o.id === uploadTarget.id ? { ...o, referencePhotos: [...(o.referencePhotos || []), compressedBase64] } : o);
            setOutfits(updated);
            await saveOutfits(projectId, updated);
        }
        showToast("Photo uploaded", 'success');
    } catch (e) { showToast("Upload failed", 'error'); } 
    finally { setIsUploading(false); setUploadTarget(null); if(fileInputRef.current) fileInputRef.current.value = ''; }
  };

  const handleDeletePhoto = async (type: 'character' | 'outfit', id: string, idx: number) => {
     if (type === 'character') {
         const updated = characters.map(c => c.id === id ? { ...c, referencePhotos: c.referencePhotos?.filter((_, i) => i !== idx) } : c);
         setCharacters(updated); await saveCharacters(projectId, updated);
     } else {
         const updated = outfits.map(o => o.id === id ? { ...o, referencePhotos: o.referencePhotos?.filter((_, i) => i !== idx) } : o);
         setOutfits(updated); await saveOutfits(projectId, updated);
     }
     showToast("Photo deleted", 'info');
  };

  if (isLoading) return <div className="p-8 text-center text-text-tertiary">Loading Assets...</div>;

  return (
    <div className="flex h-full overflow-hidden bg-background">
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
      
      {previewImage && (
          <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-8 animate-in fade-in" onClick={() => setPreviewImage(null)}>
              <img src={previewImage} className="max-w-full max-h-full object-contain shadow-2xl rounded" alt="Preview" />
              <button onClick={() => setPreviewImage(null)} className="absolute top-4 right-4 text-white p-2"><X className="w-8 h-8"/></button>
          </div>
      )}

      {/* LEFT PANEL: CHARACTERS */}
      <div className="w-[40%] min-w-[320px] border-r border-border flex flex-col bg-surface">
         <div className="h-14 px-6 border-b border-border flex items-center justify-between bg-surface-secondary">
            <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">Cast List</span>
            <span className="text-xs text-text-tertiary">{characters.length} Actors</span>
         </div>
         
         <div className="p-6 border-b border-border space-y-3 bg-surface">
            <input 
               className="studio-input" 
               placeholder="Character Name"
               value={newCharName} onChange={e => setNewCharName(e.target.value)}
            />
            <div className="flex gap-2">
               <input 
                  className="studio-input flex-1" 
                  placeholder="Description (e.g. Tall, grim)"
                  value={newCharDesc} onChange={e => setNewCharDesc(e.target.value)}
               />
               <button onClick={handleAddCharacter} disabled={!newCharName} className="studio-btn studio-btn-secondary w-10 px-0">
                  <Plus className="w-5 h-5" />
               </button>
            </div>
         </div>

         <div className="flex-1 overflow-y-auto">
            {characters.map(char => (
               <div 
                  key={char.id}
                  onClick={() => setSelectedCharId(char.id)}
                  className={`
                     p-4 border-b border-border cursor-pointer transition-colors group relative
                     ${selectedCharId === char.id ? 'bg-primary/5 border-l-4 border-l-primary' : 'hover:bg-surface-secondary border-l-4 border-l-transparent'}
                  `}
               >
                  <div className="flex justify-between items-start mb-3">
                     <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${selectedCharId === char.id ? 'bg-primary text-white' : 'bg-surface-secondary text-text-tertiary'}`}>
                           <User className="w-5 h-5" />
                        </div>
                        <div>
                           <div className={`font-semibold text-sm ${selectedCharId === char.id ? 'text-primary' : 'text-text-primary'}`}>{char.name}</div>
                           <div className="text-xs text-text-secondary">{char.description}</div>
                        </div>
                     </div>
                     <button 
                        onClick={(e) => { e.stopPropagation(); handleDeleteCharacter(char.id); }} 
                        className="opacity-0 group-hover:opacity-100 text-text-tertiary hover:text-error p-2"
                     >
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  
                  <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
                     <button 
                        onClick={(e) => { e.stopPropagation(); triggerImageUpload('character', char.id); }}
                        className="w-10 h-10 border border-dashed border-border rounded-md flex items-center justify-center text-text-tertiary hover:text-primary hover:border-primary shrink-0 transition-colors"
                     >
                        {isUploading && uploadTarget?.id === char.id ? <Loader2 className="w-3 h-3 animate-spin"/> : <Upload className="w-3 h-3"/>}
                     </button>
                     {char.referencePhotos?.map((p, i) => (
                        <div key={i} className="relative w-10 h-10 shrink-0 group/img">
                           <img src={p} className="w-full h-full object-cover rounded-md border border-border cursor-pointer" onClick={(e) => { e.stopPropagation(); setPreviewImage(p); }} />
                           <button 
                              onClick={(e) => { e.stopPropagation(); handleDeletePhoto('character', char.id, i); }} 
                              className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover/img:opacity-100 text-white rounded-md"
                           >
                              <X className="w-3 h-3" />
                           </button>
                        </div>
                     ))}
                  </div>
               </div>
            ))}
         </div>
      </div>

      {/* RIGHT PANEL: OUTFITS */}
      <div className="flex-1 bg-background flex flex-col">
         <div className="h-14 px-6 border-b border-border flex items-center justify-between bg-surface-secondary">
             <div className="flex items-center gap-2">
                 <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">Wardrobe</span>
                 {selectedCharId && <span className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded font-medium">{characters.find(c => c.id === selectedCharId)?.name}</span>}
             </div>
         </div>

         {!selectedCharId ? (
             <div className="flex-1 flex flex-col items-center justify-center text-text-tertiary">
                 <Shirt className="w-12 h-12 mb-4 opacity-20" />
                 <p>Select a character to manage wardrobe</p>
             </div>
         ) : (
             <div className="flex-1 overflow-y-auto p-8">
                 <div className="studio-card p-4 mb-6">
                     <div className="flex gap-3 mb-3">
                        <input className="studio-input w-1/3" placeholder="Outfit Name" value={newOutfitName} onChange={e => setNewOutfitName(e.target.value)}/>
                        <input className="studio-input flex-1" placeholder="Visual details..." value={newOutfitDesc} onChange={e => setNewOutfitDesc(e.target.value)}/>
                        <button onClick={handleAddOutfit} disabled={!newOutfitName} className="studio-btn studio-btn-primary">Add</button>
                     </div>
                 </div>

                 <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                     {outfits.filter(o => o.characterId === selectedCharId).map(outfit => (
                         <div key={outfit.id} className="studio-card p-4 relative group">
                             <button onClick={() => handleDeleteOutfit(outfit.id)} className="absolute top-3 right-3 text-text-tertiary hover:text-error opacity-0 group-hover:opacity-100 transition-opacity p-2">
                                <Trash2 className="w-4 h-4"/>
                             </button>
                             <div className="flex items-center gap-3 mb-3">
                                 <div className="w-10 h-10 bg-surface-secondary rounded-lg flex items-center justify-center text-text-tertiary"><Shirt className="w-5 h-5"/></div>
                                 <div>
                                     <div className="text-text-primary font-medium text-sm">{outfit.name}</div>
                                     <div className="text-xs text-text-secondary">{outfit.description}</div>
                                 </div>
                             </div>
                             <div className="flex gap-2 mt-2 pt-2 border-t border-border">
                                 <button onClick={() => triggerImageUpload('outfit', outfit.id)} className="w-12 h-12 border border-dashed border-border rounded-lg flex items-center justify-center hover:bg-surface-secondary transition-colors">
                                     {isUploading && uploadTarget?.id === outfit.id ? <Loader2 className="w-4 h-4 animate-spin"/> : <Plus className="w-4 h-4 text-text-tertiary"/>}
                                 </button>
                                 {outfit.referencePhotos?.map((p, i) => (
                                     <div key={i} className="relative w-12 h-12 group/img">
                                        <img src={p} className="w-full h-full object-cover rounded-lg border border-border cursor-pointer" onClick={() => setPreviewImage(p)} />
                                        <button onClick={() => handleDeletePhoto('outfit', outfit.id, i)} className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover/img:opacity-100 text-white rounded-lg">
                                            <X className="w-3 h-3" />
                                        </button>
                                     </div>
                                 ))}
                             </div>
                         </div>
                     ))}
                 </div>
             </div>
         )}
      </div>
    </div>
  );
};
