
/*
 * 🎞️ COMPONENT: TIMELINE VIEW
 * Commercial Quality Update: Teal Theme & Studio Classes
 */

import React, { useState, useEffect } from 'react';
import { Project, Shot, Scene, ShowToastFn, ScriptElement } from '../types';
import { parseScript } from '../services/scriptParser';
import { Plus, Trash2, ArrowUp, ArrowDown, Film, MessageSquare, Clapperboard, Upload, Loader2 } from 'lucide-react';
import { ScriptElementCard } from './ScriptElementCard';

interface TimelineViewProps {
  project: Project;
  onUpdateProject: (project: Project) => void;
  onEditShot: (shot: Shot) => void;
  showToast: ShowToastFn;
}

export const TimelineView: React.FC<TimelineViewProps> = ({ project, onUpdateProject, onEditShot, showToast }) => {
  const [scriptElements, setScriptElements] = useState<ScriptElement[]>([]);
  const [isUploadingScript, setIsUploadingScript] = useState(false);

  useEffect(() => {
    if (project.scriptElements) {
      setScriptElements(project.scriptElements);
    }
  }, [project]);

  const handleScriptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsUploadingScript(true);
    
    try {
      const parsed = await parseScript(file);
      
      const updatedProject = {
        ...project,
        scenes: parsed.scenes,
        scriptElements: parsed.elements,
        scriptFile: {
          name: file.name,
          uploadedAt: Date.now(),
          format: file.name.endsWith('.fountain') ? 'fountain' as const : 'txt' as const
        }
      };
      
      // Update project via parent handler
      onUpdateProject(updatedProject);
      
      // Update local state
      setScriptElements(parsed.elements);
      
      showToast(
        `Script imported: ${parsed.scenes.length} scenes, ${parsed.elements.length} elements`,
        'success'
      );
      
    } catch (error: any) {
      console.error(error);
      showToast('Failed to parse script: ' + (error.message || 'Unknown error'), 'error');
    } finally {
      setIsUploadingScript(false);
    }
  };

  const handleAddScene = () => {
    const newScene: Scene = { id: crypto.randomUUID(), sequence: project.scenes.length + 1, heading: 'INT. NEW SCENE - DAY', actionNotes: '' };
    onUpdateProject({ ...project, scenes: [...project.scenes, newScene] });
    showToast("Scene added", 'success');
  };

  const handleUpdateScene = (sceneId: string, updates: Partial<Scene>) => {
    const updatedScenes = project.scenes.map(s => s.id === sceneId ? { ...s, ...updates } : s);
    onUpdateProject({ ...project, scenes: updatedScenes });
  };

  const handleDeleteScene = (sceneId: string) => {
    if (!confirm("Delete this scene?")) return;
    const sceneToDelete = project.scenes.find(s => s.id === sceneId);
    if (!sceneToDelete) return;

    const updatedShots = project.shots.filter(s => s.sceneId !== sceneId);
    const updatedScenes = project.scenes.filter(s => s.id !== sceneId);
    onUpdateProject({ ...project, scenes: updatedScenes, shots: updatedShots });
    showToast("Scene deleted", 'info');
  };

  const handleDeleteShot = (shotId: string) => {
    const shotToDelete = project.shots.find(s => s.id === shotId);
    if (!shotToDelete) return;

    // Remove from project shots
    const updatedShots = project.shots.filter(s => s.id !== shotId);
    
    // Also unlink from any script elements
    const updatedElements = scriptElements.map(el => ({
        ...el,
        associatedShotIds: el.associatedShotIds?.filter(id => id !== shotId)
    }));

    onUpdateProject({ ...project, shots: updatedShots, scriptElements: updatedElements });
    setScriptElements(updatedElements);

    // Show Undo Toast
    showToast("Shot deleted", 'info', {
        label: "Undo",
        onClick: () => {
            // Restore
            onUpdateProject({ ...project, shots: [...updatedShots, shotToDelete], scriptElements: project.scriptElements });
            setScriptElements(project.scriptElements || []);
            showToast("Shot restored", 'success');
        }
    });
  };

  const moveScene = (index: number, dir: 'up' | 'down') => {
    if ((dir === 'up' && index === 0) || (dir === 'down' && index === project.scenes.length - 1)) return;
    const newScenes = [...project.scenes];
    const target = dir === 'up' ? index - 1 : index + 1;
    [newScenes[index], newScenes[target]] = [newScenes[target], newScenes[index]];
    newScenes.forEach((s, i) => s.sequence = i + 1);
    onUpdateProject({ ...project, scenes: newScenes });
  };

  const handleAddShotToScene = (sceneId: string) => {
    const newShot: Shot = {
      id: crypto.randomUUID(), sceneId: sceneId, sequence: project.shots.length + 1, description: '', notes: '',
      characterIds: [], shotType: 'Wide Shot', aspectRatio: project.settings.aspectRatio, dialogue: ''
    };
    onUpdateProject({ ...project, shots: [...project.shots, newShot] });
    onEditShot(newShot);
  };

  // --- SCRIPT LINKING LOGIC ---
  const handleLinkShot = async (elementId: string) => {
    const element = scriptElements.find(el => el.id === elementId);
    if (!element?.sceneId) return;
    
    const sceneShots = project.shots.filter(shot => shot.sceneId === element.sceneId);
    
    if (sceneShots.length === 0) {
      showToast('No shots in this scene to link', 'warning');
      return;
    }
    
    const shotToLink = sceneShots[0];
    
    const updatedElements = scriptElements.map(el => {
      if (el.id === elementId) {
        const currentLinks = el.associatedShotIds || [];
        if (currentLinks.includes(shotToLink.id)) {
          showToast('Shot already linked', 'warning');
          return el;
        }
        return {
          ...el,
          associatedShotIds: [...currentLinks, shotToLink.id]
        };
      }
      return el;
    });
    
    const updatedProject = { ...project, scriptElements: updatedElements };
    onUpdateProject(updatedProject);
    setScriptElements(updatedElements);
    showToast('Shot linked successfully', 'success');
  };

  const handleUnlinkShot = async (elementId: string, shotId: string) => {
    const updatedElements = scriptElements.map(el => {
      if (el.id === elementId) {
        return { ...el, associatedShotIds: el.associatedShotIds?.filter(id => id !== shotId) || [] };
      }
      return el;
    });
    
    const updatedProject = { ...project, scriptElements: updatedElements };
    onUpdateProject(updatedProject);
    setScriptElements(updatedElements);
    showToast('Shot unlinked', 'success');
  };

  const getMergedTimeline = (sceneId: string) => {
    const sceneShots = project.shots.filter(shot => shot.sceneId === sceneId);
    const sceneElements = scriptElements.filter(el => el.sceneId === sceneId);
    
    const merged = [
      ...sceneShots.map(shot => ({ ...shot, itemType: 'shot' as const })),
      ...sceneElements.map(el => ({ ...el, itemType: 'element' as const }))
    ].sort((a, b) => a.sequence - b.sequence);
    
    return merged;
  };

  return (
    <div className="h-full bg-background overflow-y-auto p-8 font-sans">
      <div className="max-w-5xl mx-auto pb-20">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8 sticky top-0 z-20 bg-background/95 backdrop-blur py-4 border-b border-border">
             <h2 className="text-lg font-bold text-text-primary tracking-wide flex items-center gap-3">
                <div className="p-2 bg-surface-secondary rounded border border-border"><Clapperboard className="w-5 h-5 text-primary" aria-hidden="true" /></div>
                SEQUENCE EDITOR
             </h2>
             
             <div className="flex items-center gap-3">
                 <input
                    type="file"
                    accept=".fountain,.txt"
                    onChange={handleScriptUpload}
                    className="hidden"
                    id="script-upload-input"
                 />
                 <label htmlFor="script-upload-input">
                    <button
                      className="studio-btn studio-btn-secondary"
                      disabled={isUploadingScript}
                      onClick={() => document.getElementById('script-upload-input')?.click()}
                    >
                      {isUploadingScript ? (
                        <>
                          <Loader2 size={16} className="animate-spin text-primary" />
                          Parsing...
                        </>
                      ) : (
                        <>
                          <Upload size={16} />
                          Import Script
                        </>
                      )}
                    </button>
                 </label>

                 <button 
                    onClick={handleAddScene}
                    className="studio-btn studio-btn-primary shadow-lg shadow-teal-900/20"
                 >
                    <Plus className="w-4 h-4" aria-hidden="true" /> New Scene
                 </button>
             </div>
        </div>

        {/* Scenes List */}
        <div className="space-y-8">
            {project.scenes.map((scene, index) => {
                const timelineItems = getMergedTimeline(scene.id);

                return (
                    <div key={scene.id} className="studio-card overflow-hidden group/scene">
                        {/* SCENE HEADER */}
                        <div className="bg-surface-secondary p-1 flex items-stretch min-h-[48px] border-b border-border">
                            <div className="flex flex-col items-center justify-center px-2 border-r border-border w-10 gap-1">
                                 <button onClick={() => moveScene(index, 'up')} className="text-text-tertiary hover:text-text-primary" aria-label="Move scene up"><ArrowUp className="w-3 h-3" aria-hidden="true"/></button>
                                 <span className="font-mono text-xs text-text-secondary">{index + 1}</span>
                                 <button onClick={() => moveScene(index, 'down')} className="text-text-tertiary hover:text-text-primary" aria-label="Move scene down"><ArrowDown className="w-3 h-3" aria-hidden="true"/></button>
                            </div>
                            
                            <div className="flex-1 px-4 py-2 flex flex-col justify-center">
                                <input 
                                    value={scene.heading}
                                    onChange={(e) => handleUpdateScene(scene.id, { heading: e.target.value.toUpperCase() })}
                                    className="bg-transparent text-text-primary font-bold text-sm font-mono outline-none placeholder-text-tertiary w-full"
                                    placeholder="INT. SCENE HEADING - DAY"
                                    aria-label="Scene Heading"
                                />
                            </div>

                            <div className="px-3 flex items-center border-l border-border">
                                <button onClick={() => handleDeleteScene(scene.id)} className="text-text-tertiary hover:text-error p-2 hover:bg-background rounded" aria-label="Delete Scene">
                                    <Trash2 className="w-4 h-4" aria-hidden="true" />
                                </button>
                            </div>
                        </div>

                        {/* TIMELINE CONTENT */}
                        <div className="p-4 bg-[#1a1a1a] space-y-3">
                             {timelineItems.length > 0 ? (
                                timelineItems.map(item => (
                                    item.itemType === 'shot' ? (
                                        // VISUAL SHOT CARD
                                        <div key={item.id} className="relative group/shot bg-surface border border-border rounded-lg p-3 flex gap-4 items-start hover:border-border-hover transition-colors shadow-sm">
                                            {/* Image Thumbnail */}
                                            <div 
                                                className="w-48 aspect-video bg-background border border-border rounded-md overflow-hidden cursor-pointer hover:border-primary transition-colors relative shrink-0"
                                                onClick={() => onEditShot(item as Shot)}
                                                role="button"
                                                aria-label={`Edit shot ${item.sequence}`}
                                            >
                                                {item.generatedImage ? (
                                                    <img src={item.generatedImage} className="w-full h-full object-cover" alt={`Shot ${item.sequence}`} />
                                                ) : (
                                                    <div className="w-full h-full flex items-center justify-center text-text-tertiary"><Film className="w-8 h-8"/></div>
                                                )}
                                                <div className="absolute top-1 left-1 bg-black/70 text-white text-[10px] px-1.5 rounded font-mono">
                                                    SHOT #{item.sequence}
                                                </div>
                                            </div>

                                            {/* Metadata */}
                                            <div className="flex-1">
                                                <div className="flex justify-between items-start mb-2">
                                                    <div className="text-xs font-bold text-primary uppercase bg-primary/10 px-2 py-0.5 rounded inline-block border border-primary/20">
                                                        {item.shotType}
                                                    </div>
                                                    <button 
                                                        onClick={(e) => { e.stopPropagation(); handleDeleteShot(item.id); }}
                                                        className="text-text-tertiary hover:text-error p-1 opacity-0 group-hover/shot:opacity-100 transition-opacity"
                                                        aria-label="Delete Shot"
                                                    >
                                                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                                                    </button>
                                                </div>
                                                <p className="text-sm text-text-primary line-clamp-3 mb-2">{item.description || "No description"}</p>
                                                {item.dialogue && (
                                                    <div className="text-xs text-text-secondary italic pl-2 border-l-2 border-border mt-2">
                                                        "{item.dialogue}"
                                                    </div>
                                                )}
                                                <div className="flex gap-4 mt-3 text-[10px] text-text-tertiary">
                                                     {item.aspectRatio && <span>Aspect: {item.aspectRatio}</span>}
                                                     {item.characterIds.length > 0 && <span>Cast: {item.characterIds.length}</span>}
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        // SCRIPT ELEMENT CARD
                                        <ScriptElementCard 
                                            key={item.id} 
                                            element={item}
                                            linkedShots={project.shots.filter(s => item.associatedShotIds?.includes(s.id))}
                                            onLinkShot={handleLinkShot}
                                            onUnlinkShot={handleUnlinkShot}
                                        />
                                    )
                                ))
                             ) : (
                                <div className="flex flex-col items-center justify-center py-12 text-text-tertiary border-2 border-dashed border-border rounded-lg">
                                    <MessageSquare className="w-8 h-8 mb-2 opacity-50" />
                                    <p className="text-sm font-medium">Scene is empty</p>
                                    <div className="flex gap-4 mt-4">
                                        <button onClick={() => document.getElementById('script-upload-input')?.click()} className="text-primary text-xs hover:underline font-medium">Import Script</button>
                                        <span className="text-border">•</span>
                                        <button onClick={() => handleAddShotToScene(scene.id)} className="text-primary text-xs hover:underline font-medium">Add Shot Manually</button>
                                    </div>
                                </div>
                             )}
                        </div>

                        {/* FOOTER ACTION */}
                        <div className="bg-surface-secondary p-2 border-t border-border flex justify-center">
                             <button 
                                onClick={() => handleAddShotToScene(scene.id)}
                                className="text-xs text-text-secondary hover:text-text-primary flex items-center gap-1 py-1 px-3 hover:bg-border rounded transition-colors font-medium"
                             >
                                <Plus className="w-3 h-3" /> Add Shot to Scene
                             </button>
                        </div>
                    </div>
                );
            })}
        </div>
      </div>
    </div>
  );
};
